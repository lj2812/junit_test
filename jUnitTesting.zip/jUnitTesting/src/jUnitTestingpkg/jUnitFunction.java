package jUnitTestingpkg;

public class jUnitFunction {
	public int addnum(int n1, int n2) {
		return n1+n2;
	}
	public String addstring(String s1 , String s2) {
		return s1+s2;
	}
}
